<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Esperando nacer &#8212; WordPress</title>
			<style type="text/css">
			form#loginform p.galogin {
				background: none repeat scroll 0 0 #2EA2CC;
				border-color: #0074A2;
				box-shadow: 0 1px 0 rgba(120, 200, 230, 0.5) inset, 0 1px 0 rgba(0, 0, 0, 0.15);
				color: #FFFFFF;
				text-decoration: none;
				text-align: center;
				vertical-align: middle;
				border-radius: 3px;
				padding: 4px;
				height: 27px;
				font-size: 14px;
				margin-bottom: 6px;
			}
			
			form#loginform p.galogin a {
				color: #FFFFFF;
				line-height: 27px;
				font-weight: bold;
			}

			form#loginform p.galogin a:hover {
				color: #CCCCCC;
			}
			
			h3.galogin-or {
				text-align: center;
				margin-top: 16px;
				margin-bottom: 16px;
			}
			
			p.galogin-powered {
				font-size: 0.7em;
				font-style: italic;
				text-align: right;
			}
			
			p.galogin-logout {
			  	background-color: #FFFFFF;
				border: 4px solid #CCCCCC;
				box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.1);
				padding: 12px;
				margin: 12px 0;
			}
			
						
		 </style>
	<link rel='dns-prefetch' href='//hjg.com.ar' />
<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='https://hjg.com.ar/blog2/wp-admin/load-scripts.php?c=1&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.9.25'></script>
<script type='text/javascript' src='https://hjg.com.ar/blog2/wp-content/plugins/twiget/js/twiget.js?ver=4.9.25'></script>
<link rel='stylesheet' href='https://hjg.com.ar/blog2/wp-admin/load-styles.php?c=1&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.9.25' type='text/css' media='all' />
<link rel='stylesheet' id='twiget-widget-css-css'  href='https://hjg.com.ar/blog2/wp-content/plugins/twiget/css/twiget.css?ver=4.9.25' type='text/css' media='all' />
	<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
		</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Powered by WordPress</a></h1>
	
<form name="loginform" id="loginform" action="https://hjg.com.ar/blog2/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
			<p class="galogin"> 
			<a href="?error=ga_needs_configuring">Login with Google</a>
		</p>
		
				<p class='galogin-powered'>Powered by <a href='http://wp-glogin.com/?utm_source=Login%20Form&utm_medium=freemium&utm_campaign=LoginForm' target="_blank">wp-glogin.com</a></p>
				
		<script>
		jQuery(document).ready(function(){
						
			var loginform = jQuery('#loginform,#front-login-form');
			var googlelink = jQuery('p.galogin');
			var poweredby = jQuery('p.galogin-powered');

							loginform.prepend("<h3 class='galogin-or'>or</h3>");
						
			if (poweredby) {
				loginform.prepend(poweredby);
			}
			loginform.prepend(googlelink);

					});
		</script>
	<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="https://hjg.com.ar/blog2/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="https://hjg.com.ar/blog2/wp-login.php?action=lostpassword">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://hjg.com.ar/blog2/">&larr; Back to Esperando nacer</a></p>
		
	</div>

	
		<div class="clear"></div>
	</body>
	</html>
	